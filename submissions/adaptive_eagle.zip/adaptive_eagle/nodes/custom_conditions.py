"""
Adaptive Eagle 커스텀 조건 노드 — 제출용 (self-contained)

src.intent 의존 제거: EnemyIntentIs를 inline 정의.
모델 파일(intent_model.pt)이 nodes/ 안에 있으면 자동 로드하여 실시간 추론,
없으면 항상 FAILURE 반환 (safe fallback → EIM 브랜치 스킵).
"""

import logging
from pathlib import Path
from collections import deque

import py_trees

logger = logging.getLogger(__name__)


# ─── EIM Self-contained 추론 ──────────────────────────────────

_EIM_TRACKER = None
_EIM_LOAD_ATTEMPTED = False


def _try_load_eim():
    """nodes/ 디렉토리에서 intent_model.pt를 찾아 tracker 초기화."""
    global _EIM_TRACKER, _EIM_LOAD_ATTEMPTED
    if _EIM_LOAD_ATTEMPTED:
        return
    _EIM_LOAD_ATTEMPTED = True
    model_path = Path(__file__).parent / "intent_model.pt"
    if not model_path.exists():
        logger.info("EIM model not found, EnemyIntentIs will always return FAILURE")
        return
    try:
        import torch
        data = torch.load(str(model_path), map_location="cpu", weights_only=False)
        _EIM_TRACKER = _EIMTracker(data)
        logger.info(f"EIM model loaded: {model_path}")
    except Exception as e:
        logger.warning(f"EIM load failed: {e}")


class _EIMTracker:
    """경량 EIM 추론기 — ProtoNet + GRU encoder inline."""

    INTENT_CLASSES = ["GUN_ATTACK", "PURSUIT", "DEFENSIVE",
                      "ENERGY", "NEUTRAL_CIRCLE", "NEUTRAL_SCISSORS"]
    CONT_FEATURES = [
        "distance_ft", "ata_deg", "aa_deg", "hca_deg",
        "relative_bearing_deg", "ego_altitude_ft", "ego_vc_kts",
        "specific_energy_ft", "ps_fts", "energy_diff_ft",
        "closure_rate_kts", "turn_rate_degs", "alt_gap_ft", "tau_deg",
    ]
    BOOL_FEATURES = [
        "in_wez", "enm_in_wez", "in_39_line", "overshoot_risk",
        "energy_advantage", "alt_advantage", "spd_advantage",
    ]
    BFM_CLASSES = [
        "OBFM", "DBFM", "HABFM", "UNKNOWN",
        "UNK_NEAR_OFF", "UNK_SCISSORS", "UNK_DISENGAGING",
    ]
    NORM_MEAN = {
        "distance_ft": 15000.0, "ata_deg": 90.0, "aa_deg": 90.0,
        "hca_deg": 180.0, "relative_bearing_deg": 0.0,
        "ego_altitude_ft": 15000.0, "ego_vc_kts": 400.0,
        "specific_energy_ft": 20000.0, "ps_fts": 0.0, "energy_diff_ft": 0.0,
        "closure_rate_kts": 0.0, "turn_rate_degs": 0.0,
        "alt_gap_ft": 0.0, "tau_deg": 0.0,
    }
    NORM_STD = {
        "distance_ft": 10000.0, "ata_deg": 60.0, "aa_deg": 60.0,
        "hca_deg": 100.0, "relative_bearing_deg": 90.0,
        "ego_altitude_ft": 10000.0, "ego_vc_kts": 100.0,
        "specific_energy_ft": 5000.0, "ps_fts": 500.0, "energy_diff_ft": 5000.0,
        "closure_rate_kts": 200.0, "turn_rate_degs": 10.0,
        "alt_gap_ft": 5000.0, "tau_deg": 60.0,
    }

    def __init__(self, model_data, window_size=20, update_interval=10,
                 confidence_threshold=0.35):
        import torch
        import torch.nn as nn
        import torch.nn.functional as F

        self.torch = torch
        self.F = F
        self.window_size = window_size
        self.update_interval = update_interval
        self.confidence_threshold = confidence_threshold
        self._buffer = deque(maxlen=window_size)
        self._tick = 0
        self._last_intent = "UNKNOWN"
        self._last_conf = {c: 0.0 for c in self.INTENT_CLASSES}

        # encoder 재구성
        sd = model_data["encoder_state"]
        hidden_dim = sd["gru.weight_ih_l0"].shape[0] // 3
        embed_dim = sd["proj.3.weight"].shape[0]
        obs_dim = 28

        self.gru = nn.GRU(input_size=obs_dim, hidden_size=hidden_dim,
                          num_layers=2, batch_first=True, dropout=0.1)
        self.attn = nn.Linear(hidden_dim, 1)
        self.proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(),
            nn.Dropout(0.1), nn.Linear(hidden_dim, embed_dim))

        # state dict 로드
        gru_keys = {k: v for k, v in sd.items() if k.startswith("gru.")}
        self.gru.load_state_dict(gru_keys)
        self.attn.load_state_dict(
            {k.replace("attn.", ""): v for k, v in sd.items() if k.startswith("attn.")})
        proj_keys = {k.replace("proj.", ""): v for k, v in sd.items() if k.startswith("proj.")}
        self.proj.load_state_dict(proj_keys)

        self.gru.eval()
        self.attn.eval()
        self.proj.eval()

        self.temperature = model_data["temperature"]
        self._prototypes = model_data["prototypes"]

    def _obs_to_vec(self, obs):
        vec = []
        for f in self.CONT_FEATURES:
            val = float(obs.get(f, 0.0))
            val = (val - self.NORM_MEAN[f]) / (self.NORM_STD[f] + 1e-8)
            vec.append(val)
        for f in self.BOOL_FEATURES:
            raw = obs.get(f, False)
            if isinstance(raw, str):
                raw = raw.lower() == "true"
            vec.append(float(bool(raw)))
        bfm = obs.get("bfm_situation", "UNKNOWN")
        for cls in self.BFM_CLASSES:
            vec.append(1.0 if bfm == cls else 0.0)
        return self.torch.tensor(vec, dtype=self.torch.float32)

    def _encode(self, window_tensor):
        """(1, K, obs_dim) → (embed_dim,)"""
        with self.torch.no_grad():
            out, _ = self.gru(window_tensor)
            attn_w = self.F.softmax(self.attn(out), dim=1)
            context = (out * attn_w).sum(dim=1)
            emb = self.proj(context)
            return self.F.normalize(emb, dim=-1).squeeze(0)

    def update(self, obs):
        self._buffer.append(obs)
        self._tick += 1
        if (len(self._buffer) >= self.window_size
                and self._tick % self.update_interval == 0):
            self._recompute()

    def _recompute(self):
        window = [self._obs_to_vec(o) for o in self._buffer]
        tensor = self.torch.stack(window).unsqueeze(0)
        emb = self._encode(tensor)

        classes = list(self._prototypes.keys())
        protos = self.torch.stack([self._prototypes[c] for c in classes])
        dists = self.torch.norm(emb.unsqueeze(0) - protos, dim=-1)
        logits = -dists / abs(self.temperature)
        probs = self.F.softmax(logits, dim=-1).tolist()
        conf = {c: float(p) for c, p in zip(classes, probs)}
        pred = classes[int(dists.argmin())]
        max_conf = conf.get(pred, 0.0)

        if max_conf < self.confidence_threshold:
            self._last_intent = "UNKNOWN"
        else:
            self._last_intent = pred
        self._last_conf = conf

    def current_intent(self):
        return self._last_intent, self._last_conf


# ─── 조건 노드 베이스 ─────────────────────────────────────────

class _CondBase(py_trees.behaviour.Behaviour):
    def __init__(self, name):
        super().__init__(name)
        self.blackboard = self.attach_blackboard_client()
        self.blackboard.register_key(key="observation", access=py_trees.common.Access.READ)

    def _obs(self):
        return self.blackboard.observation

    def _ok(self):
        return py_trees.common.Status.SUCCESS

    def _no(self):
        return py_trees.common.Status.FAILURE


# ═══════════════════════════════════════════════════════════════
# EIM 조건 노드 (self-contained)
# ═══════════════════════════════════════════════════════════════

class EnemyIntentIs(_CondBase):
    """적의 현재 intent가 지정 클래스와 일치하는지 확인.

    self-contained: src.intent 의존 없음.
    nodes/intent_model.pt 있으면 자체 추론, 없으면 항상 FAILURE.
    """
    TUNABLE_PARAMS = {}

    def __init__(self, name="EnemyIntentIs", intent="GUN_ATTACK",
                 min_confidence=0.35):
        super().__init__(name)
        self.intent = intent
        self.min_confidence = min_confidence

    def update(self):
        try:
            _try_load_eim()
            if _EIM_TRACKER is None:
                return self._no()
            obs = self._obs()
            _EIM_TRACKER.update(obs)
            pred, conf = _EIM_TRACKER.current_intent()
            if pred == self.intent:
                c = conf.get(self.intent, 0.0)
                if c >= self.min_confidence:
                    return self._ok()
            return self._no()
        except Exception:
            return self._no()


# ═══════════════════════════════════════════════════════════════
# 1. 기하학 조건
# ═══════════════════════════════════════════════════════════════

class IsDefensiveGeometry(_CondBase):
    """AO > threshold AND TA < threshold → 방어 필요."""
    TUNABLE_PARAMS = {
        "ao_min_deg": {"type": "cont", "range": (60, 150), "default": 90},
        "ta_max_deg": {"type": "cont", "range": (30, 120), "default": 70},
    }

    def __init__(self, name="IsDefensiveGeometry", ao_min_deg=90.0, ta_max_deg=70.0):
        super().__init__(name)
        self.ao_min = ao_min_deg
        self.ta_max = ta_max_deg

    def update(self):
        try:
            obs = self._obs()
            ao = obs.get("ata_deg", 0.5) * 180
            ta = obs.get("aa_deg", 0.5) * 180
            return self._ok() if ao > self.ao_min and ta < self.ta_max else self._no()
        except Exception:
            return self._no()


class IsOffensiveGeometry(_CondBase):
    """AO < threshold AND TA > threshold → 공격 유리."""
    TUNABLE_PARAMS = {
        "ao_max_deg": {"type": "cont", "range": (20, 60), "default": 45},
        "ta_min_deg": {"type": "cont", "range": (80, 150), "default": 100},
    }

    def __init__(self, name="IsOffensiveGeometry", ao_max_deg=45.0, ta_min_deg=100.0):
        super().__init__(name)
        self.ao_max = ao_max_deg
        self.ta_min = ta_min_deg

    def update(self):
        try:
            obs = self._obs()
            ao = obs.get("ata_deg", 0.5) * 180
            ta = obs.get("aa_deg", 0.5) * 180
            return self._ok() if ao < self.ao_max and ta > self.ta_min else self._no()
        except Exception:
            return self._no()


class IsNeutralGeometry(_CondBase):
    """AO 40~100° → 중립 (선회전 영역)."""
    TUNABLE_PARAMS = {
        "ao_min_deg": {"type": "cont", "range": (30, 60), "default": 40},
        "ao_max_deg": {"type": "cont", "range": (80, 130), "default": 100},
    }

    def __init__(self, name="IsNeutralGeometry", ao_min_deg=40.0, ao_max_deg=100.0):
        super().__init__(name)
        self.ao_min = ao_min_deg
        self.ao_max = ao_max_deg

    def update(self):
        try:
            obs = self._obs()
            ao = obs.get("ata_deg", 0.5) * 180
            return self._ok() if self.ao_min <= ao <= self.ao_max else self._no()
        except Exception:
            return self._no()


# ═══════════════════════════════════════════════════════════════
# 2. 에너지 조건
# ═══════════════════════════════════════════════════════════════

class IsHighEnergy(_CondBase):
    """에너지 우위 + 특정 에너지 차이 이상."""
    TUNABLE_PARAMS = {
        "energy_diff_min_ft": {"type": "cont", "range": (0, 5000), "default": 1000},
    }

    def __init__(self, name="IsHighEnergy", energy_diff_min_ft=1000.0):
        super().__init__(name)
        self.energy_diff_min = energy_diff_min_ft

    def update(self):
        try:
            obs = self._obs()
            e_adv = obs.get("energy_advantage", False)
            e_diff = obs.get("energy_diff_ft", 0)
            return self._ok() if e_adv and e_diff > self.energy_diff_min else self._no()
        except Exception:
            return self._no()


class IsLowEnergy(_CondBase):
    """에너지 열위."""
    TUNABLE_PARAMS = {
        "energy_diff_max_ft": {"type": "cont", "range": (-5000, 0), "default": -1000},
    }

    def __init__(self, name="IsLowEnergy", energy_diff_max_ft=-1000.0):
        super().__init__(name)
        self.energy_diff_max = energy_diff_max_ft

    def update(self):
        try:
            obs = self._obs()
            e_diff = obs.get("energy_diff_ft", 0)
            return self._ok() if e_diff < self.energy_diff_max else self._no()
        except Exception:
            return self._no()


# ═══════════════════════════════════════════════════════════════
# 3. 교전 조건
# ═══════════════════════════════════════════════════════════════

class IsCloseCombat(_CondBase):
    """거리 < threshold → 근접전."""
    TUNABLE_PARAMS = {
        "dist_max_ft": {"type": "cont", "range": (1000, 6000), "default": 3000},
    }

    def __init__(self, name="IsCloseCombat", dist_max_ft=3000.0):
        super().__init__(name)
        self.dist_max = dist_max_ft

    def update(self):
        try:
            return self._ok() if self._obs().get("distance_ft", 99999) < self.dist_max else self._no()
        except Exception:
            return self._no()


class IsWEZOpportunity(_CondBase):
    """WEZ 진입 가능 조건: ATA < threshold + 거리 범위."""
    TUNABLE_PARAMS = {
        "ata_max_deg":  {"type": "cont", "range": (5, 25), "default": 15},
        "dist_max_ft":  {"type": "cont", "range": (500, 2000), "default": 914},
        "dist_min_ft":  {"type": "cont", "range": (100, 300), "default": 152},
    }

    def __init__(self, name="IsWEZOpportunity", ata_max_deg=15.0,
                 dist_max_ft=914.0, dist_min_ft=152.0):
        super().__init__(name)
        self.ata_max = ata_max_deg
        self.dist_max = dist_max_ft
        self.dist_min = dist_min_ft

    def update(self):
        try:
            obs = self._obs()
            ata = obs.get("ata_deg", 1) * 180
            dist = obs.get("distance_ft", 99999)
            return self._ok() if ata < self.ata_max and self.dist_min < dist < self.dist_max else self._no()
        except Exception:
            return self._no()


class IsUnderFire(_CondBase):
    """적 WEZ 내에 있음."""
    TUNABLE_PARAMS = {}

    def __init__(self, name="IsUnderFire"):
        super().__init__(name)

    def update(self):
        try:
            return self._ok() if self._obs().get("enm_in_wez", False) else self._no()
        except Exception:
            return self._no()


# ═══════════════════════════════════════════════════════════════
# 4. 선회전 조건
# ═══════════════════════════════════════════════════════════════

class IsOneCircleSituation(_CondBase):
    """1-circle 선회."""
    TUNABLE_PARAMS = {}

    def __init__(self, name="IsOneCircleSituation"):
        super().__init__(name)

    def update(self):
        try:
            return self._ok() if self._obs().get("tc_type", "") == "1-circle" else self._no()
        except Exception:
            return self._no()


class IsTwoCircleSituation(_CondBase):
    """2-circle 선회."""
    TUNABLE_PARAMS = {}

    def __init__(self, name="IsTwoCircleSituation"):
        super().__init__(name)

    def update(self):
        try:
            return self._ok() if self._obs().get("tc_type", "") == "2-circle" else self._no()
        except Exception:
            return self._no()


# ═══════════════════════════════════════════════════════════════
# 5. 기타
# ═══════════════════════════════════════════════════════════════

class CustomOrbitDetector(_CondBase):
    """Circular orbit lock 감지."""
    TUNABLE_PARAMS = {
        "ata_min_deg":        {"type": "cont", "range": (15, 60), "default": 35},
        "ata_max_deg":        {"type": "cont", "range": (60, 130), "default": 85},
        "closure_abs_max_kts": {"type": "cont", "range": (50, 400), "default": 200},
        "dist_min_ft":        {"type": "cont", "range": (1000, 5000), "default": 2000},
    }

    def __init__(self, name="CustomOrbitDetector", ata_min_deg=35.0, ata_max_deg=85.0,
                 closure_abs_max_kts=200.0, dist_min_ft=2000.0):
        super().__init__(name)
        self.ata_min = ata_min_deg
        self.ata_max = ata_max_deg
        self.closure_abs_max = closure_abs_max_kts
        self.dist_min = dist_min_ft

    def update(self):
        try:
            obs = self._obs()
            ata = obs.get("ata_deg", 0.5) * 180
            closure = obs.get("closure_rate_kts", 999)
            dist = obs.get("distance_ft", 0)
            if self.ata_min <= ata <= self.ata_max and abs(closure) < self.closure_abs_max and dist > self.dist_min:
                return self._ok()
            return self._no()
        except Exception:
            return self._no()


class IsOvershooting(_CondBase):
    """오버슈트 위험 감지."""
    TUNABLE_PARAMS = {
        "closure_min_kts": {"type": "cont", "range": (100, 400), "default": 200},
        "dist_max_ft":     {"type": "cont", "range": (500, 3000), "default": 1500},
    }

    def __init__(self, name="IsOvershooting", closure_min_kts=200.0, dist_max_ft=1500.0):
        super().__init__(name)
        self.closure_min = closure_min_kts
        self.dist_max = dist_max_ft

    def update(self):
        try:
            obs = self._obs()
            closure = obs.get("closure_rate_kts", 0)
            dist = obs.get("distance_ft", 99999)
            overshoot = obs.get("overshoot_risk", False)
            return self._ok() if overshoot or (closure > self.closure_min and dist < self.dist_max) else self._no()
        except Exception:
            return self._no()
